import React, {useEffect, useState} from 'react';
import { Text, View, StyleSheet, FlatList, Button } from 'react-native';
import Constants from 'expo-constants';



export default function PostDetailAndComment({navigation}) {
  
  const [PostDetail, setPostDetail] = useState([]);
  const [Comments, setComments] = useState([]);
  
  useEffect(() => { 
    
        fetch("https://jsonplaceholder.typicode.com/posts/" + navigation.getParam('id')).then(response => response.json()).then(PostDetail => {

        setPostDetail(PostDetail);
       
        });

        fetch("https://jsonplaceholder.typicode.com/posts/" + navigation.getParam('id') + "/comments").then(response => response.json()).then(Comments => {

        setComments(Comments);

         });
   


    
  });

  return (
    
    <View style={styles.container}>

    <Text>User ID: {PostDetail.userId}</Text>
    <Text>Title: {PostDetail.title}</Text>
    <Text>Body: {PostDetail.body}</Text>

    <FlatList
      data = {Comments}
      keyExtractor = {({id}, index) => id}
      renderItem = {({item}) => (
        <View>
        
      <Text>PostID: {item.postId} </Text> 
      <Text>ID: {item.id} </Text> 
      <Text>Email: {item.email} </Text> 
      <Text>Body: {item.body} </Text> 
      

        </View>
     )}/>



    </View>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  
});
