import React, {useState, useEffect} from 'react';
import { Text, View, StyleSheet, FlatList, Button, TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';

import { Card } from 'react-native-paper';

export default function ToDoList() {

    const [todo, setTodo] = useState([]);

   useEffect(() => {

     axios

      .get("https://jsonplaceholder.typicode.com/todos")

      .then(response => setTodo(response.data));

      });

  return (
    <View style={styles.container}>

      <FlatList
      keyExtractor={(item) => item.id} 
      data = {todo}
      renderItem={({ item }) => (   

       <View>

          <Text>Title: {item.title}</Text>
          <Text>Completed: {item.completed.toString()}</Text>

          </View>
   
        
      )} 

      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 10,
  },
  
  
});
