import React, {useEffect, useState} from 'react';
import { Text, View, StyleSheet, FlatList, Button, Image, } from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';




export default function PhotoList({navigation}) {
  
    const [PhotoList, setPhotoList] = useState([]);

  
  useEffect(() => { 
    
        axios

      .get ("https://jsonplaceholder.typicode.com/photos/" + navigation.getParam('id'))
      
      .then(response => setPhotoList(response.data));

     

     

      });
 
 

  return (
    
    <View style={styles.container}>
    
    <Text>AlbumID: {PhotoList.albumId}</Text>
    <Text>Title: {PhotoList.title}</Text>
     <Image style={styles.biglogo}source={PhotoList.url}></Image>
     <Image style={styles.logo}source={PhotoList.thumbnailUrl}></Image>
    </View>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  
  logo:{
    width: 150,
    height: 150,
  },

   biglogo:{
    width: 600,
    height: 600,
  },

});
